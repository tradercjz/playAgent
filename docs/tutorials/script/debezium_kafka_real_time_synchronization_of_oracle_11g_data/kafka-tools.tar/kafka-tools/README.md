### Description
kafka 数据同步运维工具


### function list
1 bin/kafka.sh  //查看kafka 的toipc 信息 
2 bin/rest.sh   //调用restful api 创建、维护 数据同步任务
3 bin/tpconsumer.sh //解析查看topic 中的数据
4 comsume.sh // 调用confluent 的kafka-avro-console-consumer 方法读取topic数据

使用须知：
1 需要先配置 config/config.properties 里头的参数
2 每个脚本都可以不带参数执行，会输出提示


